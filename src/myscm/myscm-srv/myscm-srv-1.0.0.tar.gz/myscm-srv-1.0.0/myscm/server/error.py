# -*- coding: utf-8 -*-
from myscm.common.error import MySCMError


class ServerError(MySCMError):
    pass
